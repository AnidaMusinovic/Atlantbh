/// <reference types="cypress" />
const requiredExample = require('../../fixtures/example')
import search from '../../support/pageObjects/SearchButtonPage';


context('User search products on website', () => {
 
  it('user search', () => {
    const SearchButtonPage = new search();

    cy.visit('http://automationpractice.com/index.php')
    SearchButtonPage.getSearchButton().click()
    SearchButtonPage.getProduct().type(requiredExample.search, {force: true})
    cy.wait(2000)
    

    cy.screenshot()
  })
})




