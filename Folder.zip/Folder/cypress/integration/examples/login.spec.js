/// <reference types="cypress" />
const requiredExample = require('../../fixtures/example')
import LoginPage from '../../support/pageObjects/loginPage';

context('User log in website', () => {
  
  it('user login', () => {
    const loginPage = new LoginPage();

    cy.visit('http://automationpractice.com/index.php')
    loginPage.getMyAccountButton().click()
    cy.wait(2000)
    loginPage.getEmail().type(requiredExample.email, {force: true})
    cy.wait(2000)
    loginPage.getPassword().type(requiredExample.pass, {force: true})
    cy.wait(2000)
    loginPage.getSigninButton().click({multiple: true})
    cy.screenshot()
  })
})




