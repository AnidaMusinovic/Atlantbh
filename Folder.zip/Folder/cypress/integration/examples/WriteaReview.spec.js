/// <reference types="cypress" />
const requiredExample = require('../../fixtures/example')
import WriteaReview from '../../support/pageObjects/WriteaReviewPage';

context('User is able to write a review for product', () => {

it('write a review', () => {
  cy.visit('http://automationpractice.com/index.php')
  const WriteaReviewPage = new WriteaReview();
  WriteaReviewPage.getMyAccountButton().click()
    cy.wait(2000)
    WriteaReviewPage.getEmail().type(requiredExample.email, {force: true})
    cy.wait(2000)
    WriteaReviewPage.getPassword().type(requiredExample.pass, {force: true})
    cy.wait(2000)
    WriteaReviewPage.getSigninButton().click({multiple: true})
    cy.wait(2000)
    WriteaReviewPage.getPage().click({multiple: true,force: true})
    cy.scrollTo('center')
    WriteaReviewPage.getProduct().click({multiple: true,force: true})
    cy.wait(2000)
    WriteaReviewPage.getReview().click({multiple: true,force: true})
    cy.wait(2000)
    WriteaReviewPage.getTitle().type(requiredExample.title, {force: true})
    WriteaReviewPage.getComment().type(requiredExample.comment, {force: true})
    WriteaReviewPage.getSendButton().click()
  
    cy.screenshot()
  })
})




