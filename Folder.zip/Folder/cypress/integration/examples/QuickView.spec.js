/// <reference types="cypress" />
const requiredExample = require('../../fixtures/example')
import QuickViewPage from '../../support/pageObjects/quickViewPage';

context('User is able to use quick view on the product', () => {
  
  it('quick view', () => {
    const quickViewPage = new QuickViewPage();

    cy.visit('http://automationpractice.com/index.php')
    cy.scrollTo('center')
    quickViewPage.getQuickView().click({multiple: true,force:true})
    cy.screenshot()
  })
})




