/// <reference types="cypress" />
const requiredExample = require('../../fixtures/example')
import logout from '../../support/pageObjects/SignOutPage';

context('User sign out from website', () => {
  
  it('user logout', () => {
    const SignOutPage = new logout();

    cy.visit('http://automationpractice.com/index.php')
    SignOutPage.getMyAccountButton().click()
    cy.wait(2000)
    SignOutPage.getEmail().type(requiredExample.email, {force: true})
    cy.wait(2000)
    SignOutPage.getPassword().type(requiredExample.pass, {force: true})
    cy.wait(2000)
    SignOutPage.getSigninButton().click({multiple: true})
    cy.wait(2000)
    SignOutPage.getSignoutButton().click()

    cy.screenshot()
  })
})




