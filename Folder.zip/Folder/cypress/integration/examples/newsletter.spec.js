/// <reference types="cypress" />
const requiredExample = require('../../fixtures/example')
import NewsletterPage from '../../support/pageObjects/newsletterPage';

context('User subscribed to newsletter', () => {
  
  it('newsletter', () => {
    const newsletterPage = new NewsletterPage();

    cy.visit('http://automationpractice.com/index.php')
    cy.scrollTo('bottom')
    newsletterPage.getEmail().type(requiredExample.email2, {force: true})
    cy.wait(2000)
    newsletterPage.getNewsletter().click({force: true, multiple: true})
    cy.screenshot()
  })
})




