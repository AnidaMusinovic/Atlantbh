/// <reference types="cypress" />
const requiredExample = require('../../fixtures/example')
import AddToCart from '../../support/pageObjects/addToCartPage';

context('User is able to add product to cart', () => {

it('add product', () => {
  cy.visit('http://automationpractice.com/index.php')
  const addToCartPage = new AddToCart();
  /*addToCartPage.getMyAccountButton().click()
    cy.wait(2000)
    addToCartPage.getEmail().type(requiredExample.email, {force: true})
    cy.wait(2000)
    addToCartPage.getPassword().type(requiredExample.pass, {force: true})
    cy.wait(2000)
    addToCartPage.getSigninButton().click({multiple: true})
    cy.wait(2000)*/
    addToCartPage.getPage().click({multiple: true,force: true})
    cy.scrollTo('center')
    addToCartPage.getProduct().click({multiple: true,force: true})
    cy.wait(2000)
    addToCartPage.getDelete()
    cy.wait(2000)
    addToCartPage.getQuantity().type(requiredExample.quantity, {force: true})
    cy.wait(2000)
    addToCartPage.getSize()
    cy.wait(2000)
    addToCartPage.getCart().click( {multiple: true,force: true})
  
    cy.screenshot()
  })
})




