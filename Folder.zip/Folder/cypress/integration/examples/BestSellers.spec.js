/// <reference types="cypress" />
const requiredExample = require('../../fixtures/example')
import BestSellersPage from '../../support/pageObjects/bestsellersPage';

context('User can see best selling products', () => {
  
  it('Best sellers', () => {
    const bestsellersPage = new BestSellersPage();

    cy.visit('http://automationpractice.com/index.php')
    cy.scrollTo(200)
    bestsellersPage.getProducts().click({multiple: true,force: true})
    cy.screenshot()
  })
})




