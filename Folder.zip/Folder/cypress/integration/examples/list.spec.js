/// <reference types="cypress" />
const requiredExample = require('../../fixtures/example')
import ListPage from '../../support/pageObjects/listPage';

context('User can see product as a list', () => {
  
  it('product list', () => {
    const listPage = new ListPage();

    cy.visit('http://automationpractice.com/index.php')
    listPage.getProduct().click({multiple: true,force: true})
    cy.scrollTo('right')
    listPage.getList().click({multiple: true,force: true})
    cy.screenshot()
  })
})




