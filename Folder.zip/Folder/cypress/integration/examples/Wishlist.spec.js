/// <reference types="cypress" />
const requiredExample = require('../../fixtures/example')

import WishlistPage from '../../support/pageObjects/wishlistPage';

context('User can add product to wishlist', () => {
  
  it('product wishlist', () => {
    const wishlistPage = new WishlistPage();

    cy.visit('http://automationpractice.com/index.php')
    
    wishlistPage.getMyAccountButton().click()
    cy.wait(2000)
    wishlistPage.getEmail().type(requiredExample.email, {force: true})
    cy.wait(2000)
    wishlistPage.getPassword().type(requiredExample.pass, {force: true})
    cy.wait(2000)
    wishlistPage.getSigninButton().click({multiple: true})
    cy.wait(2000)
    wishlistPage.getPage().click({multiple: true,force: true})
    cy.wait(2000)
    wishlistPage.getProduct().click({multiple: true,force: true})
    cy.scrollTo('center')
    wishlistPage.getWishlist().click({multiple: true,force: true})
    cy.screenshot()
  })
})




