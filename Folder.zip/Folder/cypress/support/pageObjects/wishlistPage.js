
class WishlistPage {

    getMyAccountButton() {
        return cy.get('a.login');
    }
    
    getEmail(){
        return cy.get('input[id="email"]');
    }
    
    getPassword(){
        return cy.get('input[id="passwd"]');
    }
    
    getSigninButton() {
        return cy.get('button[id="SubmitLogin"]');
    }
    


   getPage()
{
    return cy.get('a[href="http://automationpractice.com/index.php?id_category=8&controller=category"]');
}

getProduct()
{
   return cy.get('a[href="http://automationpractice.com/index.php?id_product=3&controller=product"]');
}

getWishlist()
{
//return cy.get('button[id="wishlist_button"]');
return cy.get('a[href="#"]');
}
}
export default WishlistPage
    
  