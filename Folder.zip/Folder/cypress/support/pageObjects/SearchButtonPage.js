
class search {

getSearchButton(){
    return cy.get('input[id="search_query_top"]');
}

getProduct(){
    return cy.get('input[placeholder="Search"]')
}

}

export default search
    
  