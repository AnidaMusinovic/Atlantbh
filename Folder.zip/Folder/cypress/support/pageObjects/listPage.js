
class ListPage {
   getProduct()
{
    return cy.get('a[href="http://automationpractice.com/index.php?id_category=8&controller=category"]');
}

getList(){
    return cy.get('i.icon-th-list');
}

}

export default ListPage
    
  