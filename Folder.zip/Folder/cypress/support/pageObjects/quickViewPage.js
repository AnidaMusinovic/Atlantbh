
class QuickViewPage {
 getQuickView() {
    return cy.get('a.quick-view');
}
}

export default QuickViewPage
    
  