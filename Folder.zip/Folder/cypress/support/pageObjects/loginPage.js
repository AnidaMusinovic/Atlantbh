
class LoginPage {
 getMyAccountButton() {
    return cy.get('a.login');
}

getEmail(){
    return cy.get('input[id="email"]');
}

getPassword(){
    return cy.get('input[id="passwd"]');
}

getSigninButton() {
    return cy.get('button[id="SubmitLogin"]');
}
}

export default LoginPage
    
  