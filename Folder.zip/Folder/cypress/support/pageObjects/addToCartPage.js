
class AddToCart {
   /* getMyAccountButton() {
        return cy.get('a.login');
    }
    
    getEmail(){
        return cy.get('input[id="email"]');
    }
    
    getPassword(){
        return cy.get('input[id="passwd"]');
    }
    
    getSigninButton() {
        return cy.get('button[id="SubmitLogin"]');
    }*/
    
    getPage()
    {
        return cy.get('a[href="http://automationpractice.com/index.php?id_category=8&controller=category"]');
    }
    
    getProduct()
    {
       return cy.get('a[href="http://automationpractice.com/index.php?id_product=3&controller=product"]');
    }
   
    getDelete()
    {
        return cy.get('input[name="qty"]').clear();
    }

    getQuantity(){
    return cy.get('input[name="qty"]');
    }
    
   getSize(){
       return cy.get('#group_1').select('2');
       
   }

    getCart(){
    return cy.get('button[name="Submit"]');
    }
}

export default AddToCart
    
  