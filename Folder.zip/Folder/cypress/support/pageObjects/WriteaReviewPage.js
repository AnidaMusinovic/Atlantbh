
class WriteaReview {
    getMyAccountButton() {
        return cy.get('a.login');
    }
    
    getEmail(){
        return cy.get('input[id="email"]');
    }
    
    getPassword(){
        return cy.get('input[id="passwd"]');
    }
    
    getSigninButton() {
        return cy.get('button[id="SubmitLogin"]');
    }
    



    getPage()
    {
        return cy.get('a[href="http://automationpractice.com/index.php?id_category=8&controller=category"]');
    }
    
    getProduct()
    {
       return cy.get('a[href="http://automationpractice.com/index.php?id_product=3&controller=product"]');
    }
    
    getReview(){
    return cy.get('a[href="#new_comment_form"]');
    }


    getTitle(){
    return cy.get('input[id="comment_title"]');
    }

    getComment(){
    return cy.get('textarea[id="content"]');
    }

    getSendButton() {
    return cy.get('button[id="submitNewMessage"]');
    }

}

export default WriteaReview
    
  