
class logout {
 getMyAccountButton() {
    return cy.get('a.login');
}

getEmail(){
    return cy.get('input[id="email"]');
}

getPassword(){
    return cy.get('input[id="passwd"]');
}

getSigninButton() {
    return cy.get('button[id="SubmitLogin"]');
}

getSignoutButton(){
    return cy.get('a.logout')
    }
}

export default logout
    
  