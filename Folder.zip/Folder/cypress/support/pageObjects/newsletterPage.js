class NewsletterPage {
 
getEmail(){
    return cy.get('input[id="newsletter-input"]');
}

getNewsletter(){
    return cy.get('button[name="submitNewsletter"]');
   
}
}
export default NewsletterPage
    
