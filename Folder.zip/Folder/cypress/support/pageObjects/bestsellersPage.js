
class BestSellersPage {
   getProducts()
{
    return cy.get('a[href="#blockbestsellers"]');
}
}

export default BestSellersPage
    
  